import React, { useState } from 'react';

function TrafficCopApp() {
  // State variables for incident details
  const [incidentType, setIncidentType] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState(null); // State for storing uploaded photo

  // Function to handle incident submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Logic to submit incident data to backend or dispatch system
    console.log('Incident Submitted:', {
      incidentType,
      location,
      description,
      photo // Include photo in the submitted data
    });
    // Clear form fields after submission
    setIncidentType('');
    setLocation('');
    setDescription('');
    setPhoto(null); // Clear uploaded photo
  };

  // Function to handle photo upload
  const handlePhotoUpload = (event) => {
    const uploadedPhoto = event.target.files[0];
    setPhoto(uploadedPhoto);
  };

  return (
    <div>
      <h2>Traffic Cop App</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Incident Type:
          <input
            type="text"
            value={incidentType}
            onChange={(e) => setIncidentType(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Location:
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Description:
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Upload Photo:
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
          />
        </label>
        <br />
        <button type="submit">Submit Incident</button>
      </form>
    </div>
  );
}

export default TrafficCopApp;
